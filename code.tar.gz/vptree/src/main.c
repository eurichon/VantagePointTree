#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "vptree.h"

#define SET_SIZE 10000000
#define POINT_DIM 10
#define MIN -1000.0
#define MAX 1000.0

double getRandom(float min, float max);


int main(int argc, char *argv[]) {
	srand((int)time(NULL));
	struct timespec start, finish;
	double elapsed;
	unsigned i;

	//================array initialization================
	double *data = (double *)malloc(SET_SIZE*POINT_DIM*sizeof(double));
	for(i = 0;i < SET_SIZE*POINT_DIM;++i){
		data[i] = getRandom(MIN,MAX);
	}
	if(data == NULL){
		printf("Not enought memory for creation of data.Exiting....\n");
		exit(-1);
	}
	printf("The dataset has been initialized with %i points of %i dimensions\n", SET_SIZE, POINT_DIM);

	
	clock_gettime(CLOCK_MONOTONIC, &start);
	
	vptree *T = buildvp(data,SET_SIZE,POINT_DIM);
	
	clock_gettime(CLOCK_MONOTONIC, &finish);
	elapsed = (finish.tv_sec - start.tv_sec);
	elapsed += (finish.tv_nsec - start.tv_nsec) / 1000000000.0;
	printf("\nCreation time of tree is %f\n", elapsed);

	

	getchar();
	return 0;
}



double getRandom(float min, float max) {
	float random = ((float)rand()) / (float)RAND_MAX;
	float diff = max - min;
	float r = random * diff;
	return (min + r);
}


